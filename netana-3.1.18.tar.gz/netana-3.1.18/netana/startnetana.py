#!/usr/bin/env python3

from netana import main

def startapp() :
	main()
   
if __name__ == "__main__" :
	print("Starting Netana")
	startapp()
	print("Exiting Netana")

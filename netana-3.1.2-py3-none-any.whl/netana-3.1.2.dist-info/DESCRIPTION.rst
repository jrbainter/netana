This program solves electronic AC & DC Mash and Node network equations using matrix algebra.



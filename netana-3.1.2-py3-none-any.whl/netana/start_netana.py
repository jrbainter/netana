#!/usr/bin/env python3
# Startup NetAna
from netana import main
main()
